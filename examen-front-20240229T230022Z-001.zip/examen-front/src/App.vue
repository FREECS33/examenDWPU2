<template>
  <ViewBooks />
</template>

<script setup>
import ViewBooks from './views/ViewBooks.vue';
</script>
